# MASTER-UPDATES — Lot « Table complète + 28 nœuds-degrés » (2026-07-01)

> Lot INGEST + développement produit par Claude.ai d'après le dépôt de Sidy
> (pp. 44-45, 48 + revalidation 46-47). **Le tableau synoptique des degrés 11-38
> est intégralement sourcé** ; les 28 nœuds-degrés sont générés dans la
> déclaration applicative (validé mécaniquement : 36 nœuds / 2 ancrages / 0 erreur ;
> garde-fou doublon d'id vérifié en refus). La proposition **filament**
> (al-Insān al-Kāmil) est **validée par Sidy** et consignée.

## 1. Fichiers du lot, par dossier

### À appendre
- `_inbox-addendum/addendum-gloton-pp44-45-48-degres-11-17-32-38.md` — à APPENDRE
  à `doctrinal/sources/ibn-arabi-de-la-mort-a-la-resurrection-gloton.md`, à la
  suite des deux addenda précédents (retirer le bloc « Destination » ;
  `updated: 2026-07-01`).

### atelier/projets/ (remplacements)
- `generer-manifeste.py` — **remplace** la version du lot 1 : ajout de la
  surcharge déclarative `id:` et `label:` (nécessaire aux nœuds-degrés partageant
  une même fiche source) ; contrôle de doublon inchangé et re-testé.
- `instrument-donnees.yaml` — **v0.3, remplace** la v0.2 : les 28 nœuds-degrés
  (11-38) déclarés avec `degre_vertical` numérique, groupés par bandes de la spec
  (Lāhūt 11-14, Jabarūt 15-18, Barzakh sup. 19-20, Malakūt 21-27, Nāsūt 28-38) ;
  degrés 1-10 (Hāhūt) volontairement non déclarés (vide invisible, spec de l'axe).

## 2. Éditions ciblées à appliquer

### 2a. `doctrinal/symboles/table-28-degres-nafas-rahman.md`
- Compléter les degrés **11-17 et 32-38** avec les colonnes de l'addendum 3
  (Noms Divins : al-Badîʿ, al-Bâʿith, al-Bâtin, al-Âkhir, azh-Zhâhir, al-Hakîm,
  al-Muhît ; al-ʿAzîz, ar-Razzâq, al-Mudhdhil, al-Qawiyy, al-Latîf, al-Jâmiʿ,
  Rafîʿ ad-Darajât ; Manāzil : Nattih, Batîn, Thuryyâ, Dabarân, Haqʿa,
  Nahiyya/Hanʿa, Dhirâʿ ; Dhâbih, Bulaʿ, Suʿûd, ʿAkhbiya, Muqaddam, Muʾakhkhar,
  Rishâ ; avec racines et portions de signe).
- Sourçage : « — source : [[ibn-arabi-de-la-mort-a-la-resurrection-gloton]],
  pp. 44-45 et 48 (transcription du 2026-07-01) ».
- **LEVER INTÉGRALEMENT le to-source du tableau synoptique (degrés 11-38).**
- Ajouter la référence d'édition arabe (note 16, p. 49) : Futūḥāt, Dar al-Kotob
  al-Ilmiyah, Beyrouth, 1420/1999, t. 4, pp. 29-32 (pour le ch. 198).
- `updated: 2026-07-01`.

### 2b. `atelier/projets/instrument-tradition-primordiale-architecture-v0_3.md`
- §7, proposition filament : remplacer « **proposition (non validée)** » par
  « **VALIDÉ (Sidy, 2026-07-01)** » (le reste de la phrase inchangé).
- §8 « Points restants » : le n°1 (colonnes de la table) passe à **FAIT
  intégralement (2026-07-01)** ; le n°2 (rendu al-Insān al-Kāmil) passe à
  **VALIDÉ** ; restent le calcul astrologique multi-méthodes et l'échéancier.
- `updated: 2026-07-01`.

### 2c. `atelier/projets/spec-generateur-manifeste.md`
- §4, règle 1 : ajouter « Surcharge déclarative admise : un nœud peut déclarer
  `id:` et `label:` propres lorsqu'une même fiche source porte plusieurs nœuds
  (cas des 28 nœuds-degrés, tous sourcés sur la table). » `updated: 2026-07-01`.

### 2d. `meta/projet-unifie/04-sessions-par-fonction-et-backlogs.md`
- §B : « vérifier les colonnes des degrés 11-17 et 32-38 » → **FAIT (2026-07-01)** ;
  « Générer les 38 nœuds-degrés » → **FAIT pour 11-38 (2026-07-01)** (1-10 non
  déclarés, vide invisible par spec) ; « Valider le rendu d'Al-Insān al-Kāmil » →
  **FAIT (validé)**. Reliquat des relectures [?] : voir §5 ci-dessous.

## 3. Ajouts à `doctrinal/index.md`

Aucun.

## 4. Entrée pour `annales.md` (une seule)

```
## [2026-07-01] enrichissement | Table des 28 degrés intégralement sourcée — 28 nœuds-degrés générés
Troisième dépôt de Sidy (pp. 44-45, 48) : addendum 3 appendu à la fiche source
Gloton — degrés 11-17 et 32-38 (Noms Divins, Manāzil, racines, portions
zodiacales). Le to-source du tableau synoptique (11-38) est INTÉGRALEMENT levé ;
référence d'édition arabe des Futūḥāt consignée (Dar al-Kotob al-Ilmiyah 1420/1999,
t. 4). Les 28 nœuds-degrés déclarés dans instrument-donnees.yaml v0.3 (générateur
amendé : surcharge id/label ; validation mécanique 36 nœuds / 2 ancrages / 0
erreur). Proposition filament (al-Insān al-Kāmil) validée par Sidy et consignée
(architecture v0.3 §7). L'axe complet de l'Instrument est prêt pour le premier
rendu Three.js.
```

## 5. Points sensibles

- **Ordre d'intégration** : ce lot vient APRÈS les quatre lots précédents du jour
  (générateur → v0.3 → addendum pp. 38-41 → angles/pp. 46-47). Les deux
  remplacements (script, yaml) écrasent les versions des lots 1 et 2.
- **Relectures [?] en attente de Sidy** (sans urgence, rien ne bloque) :
  1. « kanîyât [?] » (item 48, addendum pp. 38-41) — hypothèse de correction :
     **kawnîyât** (كونيات) ; vérifier p. 41 et corriger l'addendum le cas échéant.
  2. Graphie de « humide » au DS (رطب / رطوبات) — fiche `angles-de-l-espace`.
  3. Mention rouge « Devenant » près du MC — même fiche.
  4. « Samâwiyya » (degré 29) — addendum pp. 46-47 ; la seconde photo confirme la
     lecture, contrôle papier recommandé.
- **Constat de forme consigné dans l'addendum** (pas d'interprétation) : le Nom
  Divin du degré 38, *Rafîʿ ad-Darajât* (« l'Élévateur des degrés »), pour
  l'Homme parfait « synthèse de tous les degrés antérieurs ».
- La p. 49 amorce les citations discursives du ch. 198 → matière pour l'ingest
  eschatologique du backlog §E (hors périmètre de ce lot).
