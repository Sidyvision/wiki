# MASTER-UPDATES — Lot « Angles de l'Espace + Noms Divins/Manāzil pp. 46-47 » (2026-07-01)

> Lot INGEST produit par Claude.ai d'après le dépôt de Sidy du 2026-07-01 :
> photo Gloton pp. 46-47 + schéma manuscrit des angles + 3 images de référence.
> **Ce lot lève les DEUX to-source de l'architecture v0.3 §8** : (1) colonnes
> Nom Divin / Manzil des degrés 21-27 ; (2) appariement qualités ↔ angles.

## 1. Fichiers du lot, par dossier

### À appendre (pas de nouveau fichier de destination)
- `_inbox-addendum/addendum-gloton-pp46-47-noms-divins-manazil.md` — à APPENDRE à
  `doctrinal/sources/ibn-arabi-de-la-mort-a-la-resurrection-gloton.md`, à la suite
  de l'addendum pp. 38-41 (retirer le bloc « Destination » ; `updated: 2026-07-01`).

### atelier/projets/
- `angles-de-l-espace.md` — transcription du schéma manuscrit, appariement acté.
- `references-visuelles-astronomiques-phase-5.md` — catalogue des images.
- `assets-instrument/` — 4 fichiers image renommés selon la nomenclature :
  `img-0949-demeures-lunaires-zodiaque.gif`, `img-0950-angles-de-l-espace-schema.jpeg`,
  `img-0951-horizon-equateur-ecliptique.jpeg`, `img-0952-sphere-celeste-coordonnees.jpeg`.
  (La photo du livre IMG_9555 n'entre pas au dépôt : la transcription en tient lieu.)

## 2. Éditions ciblées à appliquer

### 2a. `doctrinal/symboles/table-28-degres-nafas-rahman.md`
- Compléter les degrés **21-27** avec les colonnes désormais sourcées (voir le
  tableau de l'addendum pp. 46-47) : Nom Divin (ar-Rabb, al-ʿAlîm, al-Qâhir,
  an-Nûr, al-Musawwir, al-Muhsî, al-Mubîn) et Manzil (Khurthân, Sarfa, ʿAwwâ,
  Simâk ʿaʿzal, Ghafr, Zubbân, Iklîl) avec racines et portions de signe.
- Confirmer/compléter au passage les degrés 18-20 et 28-31 (mêmes pages).
- Sourçage : « — source : [[ibn-arabi-de-la-mort-a-la-resurrection-gloton]],
  pp. 46-47 (transcription du 2026-07-01) ».
- **LEVER le to-source des colonnes Nom Divin / Manzil pour les degrés 18-31.**
  Si la fiche ne porte pas déjà ces colonnes pour les degrés **11-17 et 32-38**,
  les marquer to-source (pp. 44-45 et 48 à photographier) — ne rien y inscrire
  de mémoire.
- `updated: 2026-07-01`.

### 2b. `atelier/projets/instrument-tradition-primordiale-architecture-v0_3.md`
- §8, arbitrage n°2 : remplacer la réserve « ⚠ to-source : l'appariement exact
  qualité ↔ angle… » par : « **Appariement transcrit et acté (2026-07-01)** :
  AS = Sec, DS = Humide, MC = Chaud, FC = Froid — schéma manuscrit transcrit dans
  [[atelier/projets/angles-de-l-espace]]. »
- §8, « Points restants », n°1 : marquer FAIT pour les degrés 21-27 (colonnes
  sourcées pp. 46-47) ; reformuler le restant : « colonnes Nom Divin / Manzil des
  degrés 11-17 et 32-38 si absentes de la fiche (pp. 44-45, 48) ». Supprimer le
  point restant n°3 (appariement — fait).
- `updated: 2026-07-01`.

### 2c. `meta/projet-unifie/04-sessions-par-fonction-et-backlogs.md`
- §B : l'item « Compléter les colonnes des degrés 21-23 / 25-27 » passe à
  **FAIT (2026-07-01)** pour Lettre/ciel/jour/prophète siégeant/Nom Divin/Manzil ;
  reformuler le reliquat en « vérifier les colonnes des degrés 11-17 et 32-38 ;
  photographier pp. 44-45 et 48 si absentes ». L'item « transcrire l'appariement
  qualité ↔ angle » passe à **FAIT (2026-07-01)**.
- §B : ajouter « **[App]** Générer les 38 nœuds-degrés dans
  `instrument-donnees.yaml` (débloqué pour 18-31 ; complet après vérification
  11-17 / 32-38). »
- §E : l'item « Images de modélisation 3D (IMG_0950/0951/0952) » passe à
  **FAIT (2026-07-01)** (+ IMG_0949, non prévu au backlog, intégré au même
  catalogue).

## 3. Ajouts à `doctrinal/index.md`

Aucun (enrichissements + fiches atelier uniquement).

## 4. Entrée pour `annales.md` (une seule)

```
## [2026-07-01] enrichissement | Angles de l'Espace actés + Noms Divins/Manāzil des degrés 18-31
Second dépôt de Sidy : transcription Gloton pp. 46-47 appendue à la fiche source
(colonnes Nom Divin et Manzil des degrés 18-31, avec racines et portions
zodiacales) — levée COMPLÈTE du to-source des degrés 21-27 de
table-28-degres-nafas-rahman. Schéma manuscrit des quatre angles transcrit
(atelier/projets/angles-de-l-espace) : appariement acté AS=Sec, DS=Humide,
MC=Chaud, FC=Froid — seconde réserve to-source de l'architecture v0.3 §8 levée.
Trois images de référence astronomique cataloguées
(references-visuelles-astronomiques-phase-5, assets-instrument/). Reliquat :
vérifier les colonnes des degrés 11-17 et 32-38 (pp. 44-45, 48).
```

## 5. Points sensibles

- **Ordre d'intégration** : ce lot suppose intégrés les lots précédents du jour
  (générateur, v0.3, addendum pp. 38-41). Intégrer dans l'ordre de production.
- **Lectures incertaines** (marquées [?] dans les fiches) : la qualité du DS
  (رطب / رطوبات — le sens « humide » est sûr, la graphie exacte à confirmer) ;
  la mention rouge « Devenant » près du MC ; « Samâwiyya » (degré 29). À
  recontrôler par Sidy, sans urgence.
- **Constat de forme consigné** (pas d'interprétation) : 28 demeures / 12 signes
  = 2⅓ demeures par signe, cohérent entre le tableau de Gloton et
  l'img-0949 (28e Demeure au point vernal, 14e à l'opposé).
- Les fiches atelier lient vers `doctrinal/` à sens unique (règle respectée) ;
  `angles-de-l-espace` source la fiche `fin-des-temps-modernes-ilm-al-nujum-…`
  conformément à la question §8.2 d'origine.
