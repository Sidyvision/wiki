# MASTER-UPDATES — Lot « Transcription Gloton pp. 38-41 » (2026-07-01)

> Lot INGEST produit par Claude.ai d'après photographies des pages 38-41 de
> Ibn ʿArabī, *De la mort à la résurrection* (trad. Gloton, Albouraq), fournies par
> Sidy le 2026-07-01. Lève PARTIELLEMENT le to-source des degrés 21-27 de la table
> des 28-38 degrés (colonnes Lettre / ciel / jour / prophète siégeant désormais
> sourcées ; Nom Divin / Faṣṣ / Manzil restent to-source).

## 1. Fichiers du lot

- `addendum-gloton-degres-17-38-modes-39-50.md` — transcription structurée,
  **à APPENDRE** (pas un nouveau fichier de destination) à :
  `doctrinal/sources/ibn-arabi-de-la-mort-a-la-resurrection-gloton.md`
  (en fin de fiche, sous un titre de section ; retirer le bloc d'en-tête
  « Destination » de l'addendum lors de l'append ; `updated: 2026-07-01`).

## 2. Éditions ciblées à appliquer

### 2a. `doctrinal/symboles/table-28-degres-nafas-rahman.md`
- Compléter/confirmer les degrés **21-27** avec les données sourcées de l'addendum :

| Degré | Lettre | Ciel | Jour | Prophète siégeant |
|---|---|---|---|---|
| 21 | yâʾ (ي) | Saturne (zuhal), 1er ciel | samedi | Abraham |
| 22 | dâd (ض) | Jupiter (mushtarî), 2e ciel | jeudi | Moïse |
| 23 | lâm (ل) | Mars (mirîkh), 3e ciel | mardi | Aaron |
| 24 | nûn (ن) | Soleil (shams), 4e ciel | dimanche | Idrîs (Enoch) |
| 25 | râʾ (ر) | Vénus (zuhra), 5e ciel | vendredi | Joseph |
| 26 | tâʾ (ط) | Mercure (ʿutârid), 6e ciel | mercredi | Jésus |
| 27 | dâl (د) | Lune (qamar), 7e ciel | lundi | Adam |

- Référence de sourçage : « — source : [[ibn-arabi-de-la-mort-a-la-resurrection-gloton]],
  pp. 39-40 (transcription du 2026-07-01) ».
- **Ne PAS lever** le to-source des colonnes Nom Divin / Faṣṣ / Manzil pour ces
  degrés : non couvertes par ces pages.
- La mention « prophète siégeant » emploie le verbe de Gloton (« y siège ») —
  conserver la distinction siégeant / faṣṣ telle qu'établie dans la fiche.
- `updated: 2026-07-01`.

### 2b. `meta/projet-unifie/04-sessions-par-fonction-et-backlogs.md`
- §B, item « Compléter les colonnes des degrés 21-23 / 25-27 » : marquer
  **partiellement FAIT (2026-07-01)** — Lettre/ciel/jour/prophète siégeant sourcés
  (pp. 38-41 déposées) ; **reste** : Nom Divin / Faṣṣ / Manzil de ces degrés
  (sources pressenties : tables du ch. 198, Meftah).
- §E : ajouter un item « **Amorce possible `modes-du-souffle` (items 39-50, p. 41)** :
  matière neuve pour développer [[doctrinal/symboles/nafas-rahmani]] (stub) — la
  liste des 12 modes d'intervention du Souffle est transcrite dans l'addendum
  Gloton ; à développer lors d'un ingest de lecture dédié. »

## 3. Ajouts à `doctrinal/index.md`

Aucun (pas de nouvelle page ; enrichissements de pages existantes).

## 4. Entrée pour `annales.md` (une seule)

```
## [2026-07-01] enrichissement | Transcription Gloton pp. 38-41 — degrés 17-38 et modes 39-50
Photographies déposées par Sidy ; transcription appendue à la fiche source
ibn-arabi-de-la-mort-a-la-resurrection-gloton. Levée partielle du to-source des
degrés 21-27 de table-28-degres-nafas-rahman (Lettre/ciel/jour/prophète siégeant
désormais sourcés pp. 39-40 ; Nom Divin/Faṣṣ/Manzil restent to-source). Confirmation
textuelle du verbe « y siège » (catégorie prophète siégeant). Matière neuve
identifiée : les 12 modes d'intervention du Souffle (items 39-50) pour nafas-rahmani.
```

## 5. Points sensibles

- **Lecture incertaine unique** : item 48, « kanîyât [?] » (réalités générées) —
  graphie à recontrôler sur le papier avant tout usage doctrinal du terme.
- Les degrés 19-20 (falak al-atlas/al-burûj + falak al-kawâkib) confirment
  textuellement la bande **Barzakh supérieur (19-20)** de la spec technique de
  l'axe, et la note du degré 19 (falak al-burûj produit après le Kursî, degré 18)
  appuie l'adjacence utilisée par la correspondance falak al-burūj ↔ al-Kursī
  (lien Phase 5 ↔ Phase 2). Rien à modifier, mais bon à consigner dans la ligne
  d'annales si souhaité.
- La topographie eschatologique du degré 19-20 (Toit/Voûte du Jardin ; Terre des
  Jardins ; Feux infernaux dans la concavité) est de la matière directe pour
  [[doctrinal/symboles/eschatologie]] — à exploiter lors de l'ingest du récit
  eschatologique déjà au backlog (§E), pas dans ce lot.

## 6. Reste attendu de Sidy (inchangé)

- Le **schéma manuscrit** de l'appariement qualités élémentaires ↔ angles
  AS/DS/MC/FC (to-source de l'architecture v0.3 §8).
- Le cas échéant, les pages du ch. 198 portant les colonnes Nom Divin / Faṣṣ /
  Manzil des degrés 21-27.
