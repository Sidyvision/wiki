# MASTER-UPDATE — Enrichissement des fiches discernement (session 2026-07-08/09)

> Consigne d'intégration : « Intègre `_inbox/` selon ce MASTER-UPDATE et `CLAUDE.md`,
> fiche par fiche, dans l'ordre ci-dessous. » Chaque écriture relue avant validation
> (jamais d'auto-accept, §VIII.1). Aucun item ne touche le champ `Statut` du bloc 🔍
> (reste `en cours` partout) ni ne rédige de `Conclusion` — Cmd 12.
>
> **Nature de cette passe** : enrichissement de la *Généalogie des idées* et des
> *Lectures suggérées* de fiches `discernement` existantes, à partir de sources
> nouvellement mises en main par Sidy. PRODUCTION n'a pas vu le corps actuel de ces
> fiches (recherche partielle seulement) : **fusionner/compléter, ne jamais écraser**.
> Si le contenu existant diverge de ce qui est supposé ici, suspendre et signaler
> (Art. 3 Sashimono — jamais de joint forcé) plutôt que de forcer l'écriture.
>
> **Payload** : le contenu détaillé (citations, numéros de définition, pages exactes)
> se trouve dans les deux documents joints au sas :
> - `preparation-citations-fiches-discernement.md` — synthèse par fiche (§ correspondant
>   à chaque item ci-dessous).
> - `sept-etendards-califat-complement-transcription.md` — transcription intégrale à
>   verser dans la fiche-source Gilis (item 0 ci-dessous).

---

## Étape 0 — Fiches `source` (déjà rédigées, à déposer dans `_inbox/`)

Les cinq fiches `source` ci-dessous sont **fournies rédigées** dans
`_inbox/doctrinal/sources/` (Sceau Recteur complet, `to-source` maintenu jusqu'à
vérification primaire par Sidy). L'intégration les range et répercute leurs
`cross_links`. Références bibliographiques **vérifiées sur exemplaires physiques le
2026-07-09** (corrigent les approximations des notes de préparation) :

| Fichier fourni | Contenu | Corrections notables |
|---|---|---|
| `sources/gilis-ordo-ab-chao.md` | Gilis, *Ordo ab Chao — La Franc-Maçonnerie dans la lumière du Prophète* — transcription note liminaire, 4e de couv., table des matières, ouvrages de l'auteur, chap. VIII (p. 99-105 : Pharaon/*fard*, nombre 28, 406=*Firʿawn*) | **Éditeur = Albouraq** (ISBN 2-84161-222-8), pas « Éditions Traditionnelles ». **9 chapitres** ; « Disgrâce du Pharaon » = chap. **VIII (p. 97)**, pas 107 |
| `sources/burckhardt-introduction-doctrines-esoteriques-islam.md` | Burckhardt (Dervy) — p. 111-114 : Union, cinq Présences (texte intégral), *wilâyah* | — |
| `sources/ibn-arabi-fard-afrad-gilis.md` | Statut *Fard*/*Afrâd* via Gilis (*Études complémentaires sur le Califat*, **Paris 1994**) + contre-cas Pharaon/Vâlsan | Renvoi *afrâd* = *Trente-six Attestations coraniques de l'Unité* / *Le Coran et la fonction d'Hermès* (Paris 1994/1984). **Pagination p. 63-66 à confirmer** (marquée telle quelle dans la fiche) |
| `sources/bukhari-5754-tiyara-fal.md` | Ṣaḥīḥ al-Bukhârî 5754 — hadith complet, arabe + traduction | — |
| `sources/guenon-lettre-coomaraswamy-1936-11-05.md` | Guénon à Coomaraswamy, 5 nov. 1936 — passage sur la mémoire | — |

**Fiche existante à compléter, NE PAS recréer** :
`doctrinal/sources/sept-etendards-du-califat` — append du contenu de
`sept-etendards-califat-complement-transcription.md` en fin de fiche, `updated` à jour,
passages couverts passés de `to-source` à `sourced` en note d'état d'avancement.

> **Note sur les slugs (changement depuis la v1 du manifeste)** : slugs raccourcis —
> `gilis-ordo-ab-chao` (pas `...-disgrace-pharaon`) et `ibn-arabi-fard-afrad-gilis`
> (pas `ibn-arabi-futuhat-ch30-...`). Les étapes ci-dessous référencent les **nouveaux**
> slugs.

---

## Étape 1 — `doctrinal/discernement/2026-06-11_llm-wiki-modalite-intellect.md`
**Action** : enrichir *Lectures suggérées*. Ajouter : Al-Jurjânî, *Le Livre des
Définitions*, définitions **1754-1763** (âme, ses degrés), **793, 795** (esprit),
**724, 1431** (imagination) — numéros seuls, pas de nouvelle fiche source (l'ouvrage
Jurjânî est déjà sourcé au dépôt). `updated` → date d'intégration.
**Payload** : doc préparation, § `2026-06-11_llm-wiki-modalite-intellect`.

## Étape 2 — `doctrinal/discernement/2026-06-11_llm-wiki-correction-doctrinale.md`
**Action** : enrichissement majeur de *Généalogie des idées* et *Lectures suggérées*.
Ajouter la distinction *khalîfatun ʿan Allâhi* / *khalîfatun ʿamman salafa* (Gilis,
*Sept Étendards*, p. 249) comme filiation orthodoxe directe ; citer p. 115-121
(Califat/*wilâya*), p. 150 (Dépôt de Confiance), p. 208-211 (nom de Dâwûd). `sources` :
ajouter `"[[doctrinal/sources/sept-etendards-du-califat]]"`. `cross_links` inchangés
sauf pertinence évidente.
**Payload** : doc préparation, § `2026-06-11_llm-wiki-correction-doctrinale` (section
« En main — doctrine complète, close »).

## Étape 3 — `doctrinal/discernement/2026-06-20_visions-centre-nocturne.md`
**Action** : enrichir *Généalogie des idées* avec la triade Jurjânî 756-757-758
(*ḏū al-ʿaql* / *ḏū al-ʿayn* / synthèse, citée à Ibn ʿArabī) et les définitions
*barzakh* 295-296 ; ajouter en *Lectures suggérées* la lettre Guénon-Coomaraswamy
(5 nov. 1936) sur la mémoire. `sources` : ajouter
`"[[doctrinal/sources/guenon-lettre-coomaraswamy-1936-11-05]]"`.
**Payload** : doc préparation, § `2026-06-20_visions-centre-nocturne` (intégral).

## Étape 4 — `doctrinal/discernement/2026-06-20_matrices-artificielles-barzakh.md`
**Action** : enrichir *Généalogie* avec définitions Jurjânî *barzakh* 295 (Isthme),
296 (Intervalle totalisateur).
**Payload** : doc préparation, renvoi implicite (même famille de définitions que
l'étape 3).

## Étape 5 — `doctrinal/discernement/2026-06-20_triptyque-medine-jeu-de-piste.md`
**Action** : enrichissement de clôture matérielle (le champ `Statut` du bloc reste
`en cours`). Ajouter en *Généalogie* : définition Jurjânî 1006 (*al-ṭira*/*khîra*) et
le hadith Bukhârî 5754 (*ṭiyara*/*faʾl*) ; noter explicitement dans l'examen formel que
les deux couples lexicaux opèrent à des niveaux différents (dictionnaire technique vs
norme prophétique), sans contradiction. `sources` : ajouter
`"[[doctrinal/sources/bukhari-5754-tiyara-fal]]"`.
**Payload** : doc préparation, § `2026-06-20_triptyque-medine-jeu-de-piste` (intégral).

## Étape 6 — `doctrinal/discernement/2026-06-20_pierres-astres-barzakh.md`
**Action** : enrichir *Lectures suggérées* avec définition Jurjânî 1346 (*astre*).
Aucun changement de fond (al-Būnī toujours manquant, ne pas signaler comme résolu).
**Payload** : doc préparation, § `2026-06-20_pierres-astres-barzakh`.

## Étape 7 — `doctrinal/discernement/2026-06-20_astrologie-akbarienne-fard.md`
**Action** : enrichissement majeur. *Généalogie des idées* : ajouter (a) le critère
akbarien de reconnaissance du Fard (Ibn ʿArabī/Gilis, *Futûhât* ch. 30, cas Ibn Qāʾid)
comme filiation orthodoxe ; (b) le cas Vâlsan/Pharaon (« *fard* monstrueusement
retourné sur son moi individuel », *Ordo ab Chao* [Albouraq], chap. VIII, p. 99-100)
comme **parenté
hétérodoxe possible** — c'est un cas-limite de contrefaçon nommé, pas une simple
lecture d'appui, à placer explicitement dans le champ prévu à cet effet du bloc 🔍 ;
(c) définitions Jurjânî *fard*/*afrâd* (121-1683, liste complète en payload),
*walî*/*walâya*/*quṭbiyya* (1831-1833, 1281) ; (d) Burckhardt p. 112-113 (*wilâyah*,
Sceau, Pôle). `sources` : ajouter
`"[[doctrinal/sources/ibn-arabi-fard-afrad-gilis]]"`,
`"[[doctrinal/sources/gilis-ordo-ab-chao]]"`,
`"[[doctrinal/sources/burckhardt-introduction-doctrines-esoteriques-islam]]"`.
**Vigilance particulière** : cette fiche touche à l'auto-identification spirituelle de
Sidy — ne reformuler AUCUNE conclusion, se limiter à verser les matériaux formels.
**Payload** : doc préparation, § `2026-06-20_astrologie-akbarienne-fard` (intégral,
c'est la section la plus dense de cette passe).

## Étape 8 — `doctrinal/discernement/2026-06-20_origine-jumeau-spirituel.md`
**Action** : enrichir *Généalogie* avec définitions Jurjânî *insân kâmil* (246, 879,
1018, 1370), *marâtib*/*tartîb marâtib al-wujûd* (744-1839, liste en payload).
**Payload** : doc préparation, § `2026-06-20_origine-jumeau-spirituel`.

## Étape 9 — `doctrinal/discernement/tension-hadarat-burckhardt-jurjani.md`
**Action** : enrichissement de clôture matérielle. Verser le texte intégral de la
définition Jurjânî 631 (déjà en main via `De_finitions_d_Al_Jurjani_pour_fiches.md`,
normalement déjà source-liée) et le texte Burckhardt p. 114 note 2 (cinq Présences
nommées : Nâsût/Malakût/Jabarût/Lâhût/Hâhût). **Point d'examen formel à consigner tel
quel** : les deux nomenclatures ne se recouvrent pas terme à terme (Jurjânî ne nomme
littéralement ni *Lâhût* ni *Hâhût*) — c'est la tension elle-même, à documenter, pas à
trancher. `sources` : ajouter
`"[[doctrinal/sources/burckhardt-introduction-doctrines-esoteriques-islam]]"`.
**Payload** : doc préparation, § `tension-hadarat-burckhardt-jurjani` (intégral).

## Étape 10 — `doctrinal/discernement/2026-07-01_rafi-ad-darajat-fonction-traversante.md`
**Action** : enrichir *Généalogie* avec définitions Jurjânî *nafas raḥmânî* (553, 1333,
1763), *rang de l'Homme parfait* (1503-1504).
**Payload** : doc préparation, § `2026-07-01_rafi-ad-darajat-fonction-traversante`.

## Étape 11 — `doctrinal/discernement/2026-07-02_coudee-royale-convergence-28.md`
**Action** : ajouter en *Généalogie des idées*, **comme parenté de forme distincte du
versant architectural** (ne jamais fusionner les deux registres — Cmd 3) : la
symbolique du nombre 28 chez Gilis (*Ordo ab Chao* p. 100-105) — 28 parties des
*Fuṣûṣ*, 28 Mansions lunaires, 406=*Firʿawn*. Rappeler explicitement dans l'examen
formel que ceci est un rapprochement numérique dans un registre doctrinal, non une
confirmation du double ancrage architectural (Petrie/Cole toujours `to-source`).
`sources` : ajouter `"[[doctrinal/sources/gilis-ordo-ab-chao]]"`.
**Payload** : doc préparation, § `2026-07-02_coudee-royale-convergence-28` (intégral).

## Étape 12 — `doctrinal/discernement/2026-07-05_correspondances-fonctions-initiatiques-entreprise.md`
**Action** : enrichir *Généalogie* avec renvoi à la définition Jurjânî 631 (famille
*ḥaḍra*, déjà détaillée à l'étape 9) et *insân kâmil* (246-1370).
**Payload** : doc préparation, § `2026-07-05_correspondances-fonctions-initiatiques-entreprise`.

---

## Étape 13 — `meta/bibliotheque-physique.md`
**Action** : ajouter au catalogue (§II ou section Burckhardt/Gilis existante, omissions
de recension signalées les 2026-07-08/09) :
- Titus Burckhardt, *Introduction aux doctrines ésotériques de l'Islam* (Dervy, coll.
  « l'Être et l'Esprit »).
- Charles-André Gilis, *Ordo ab Chao — La Franc-Maçonnerie dans la lumière du Prophète*
  (**Albouraq**, ISBN 2-84161-222-8).
- Charles-André Gilis, *Les Sept Étendards du Califat* (Paris, 1993) — si pas déjà
  présent depuis l'ingestion du 2026-07-09.
- Charles-André Gilis, *Études complémentaires sur le Califat* (Paris, 1994) — référence
  de l'extrait Fard/Afrâd (pagination à confirmer sur l'exemplaire).

## Étape 14 — `doctrinal/annales.md`
**Action** : une entrée append-only, format standard :

```markdown
## [2026-07-09] discernement | Enrichissement de 10 fiches discernement (session PRODUCTION)
- **Opération** : EXAMEN DE DISCERNEMENT (lot).
- **Créé/Modifié** : 5 fiches `doctrinal/sources/` créées
  ([[doctrinal/sources/gilis-ordo-ab-chao]],
  [[doctrinal/sources/burckhardt-introduction-doctrines-esoteriques-islam]],
  [[doctrinal/sources/ibn-arabi-fard-afrad-gilis]],
  [[doctrinal/sources/bukhari-5754-tiyara-fal]],
  [[doctrinal/sources/guenon-lettre-coomaraswamy-1936-11-05]]) ; complément versé à
  [[doctrinal/sources/sept-etendards-du-califat]] ; 10 fiches
  `doctrinal/discernement/` enrichies (Généalogie des idées / Lectures suggérées) —
  voir MASTER-UPDATE pour le détail par fiche.
- **Source brute** : bibliothèque physique de Sidy (photographies), session Claude.ai
  du 2026-07-08/09.
- **Point sensible** : `astrologie-akbarienne-fard` touche à l'auto-identification
  spirituelle de Sidy — matériaux formels versés uniquement (critère akbarien de
  reconnaissance + cas-limite de contrefaçon Pharaon/Vâlsan), aucune conclusion
  rédigée. Aucun champ `Statut` de bloc 🔍 modifié dans tout le lot.
- **Note de méthode** : catalogue `bibliotheque-physique.md` mis à jour (omissions de
  recension constatées deux fois cette session — Burckhardt puis Gilis — le catalogue
  n'est pas exhaustif, vigilance à reconduire).
```

---

## Rappel de clôture (§IX CLAUDE.md)
Après application : `git diff --stat` avant commit, `compare`/VIGILANCE, contrôle
Obsidian, sas `_inbox/` vidé. Aucune étape de ce manifeste n'autorise un `Statut`
`validée`/`invalidée` ni une `Conclusion` rédigée par la machine — ces champs
restent la main de Sidy.
