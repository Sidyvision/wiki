# Préparation — Définitions/citations déjà en ta possession, par fiche discernement

*Croisement de `meta/bibliotheque-physique.md`, de `04-sessions-par-fonction-et-backlogs.md`
(§D) et des annales, au 2026-07-08. Pour chaque fiche : le thème, ce que tu peux déjà
fournir (texte + édition + ce qu'il apporte précisément), et ce qui manque encore. Ceci
prépare le terrain — la vérification du passage exact et de la pagination reste à faire
au moment du traitement (discipline des sources, §VII CLAUDE.md).*

---

## Circuit initial (14 fiches, 2026-06-11 / 2026-06-20)

### `2026-06-11_llm-wiki-modalite-intellect`
Triade Nous/Psyché/Corps ↔ architecture LLM.
- **Déjà en poche** : Guénon, *Les États multiples de l'être* (degrés ontologiques) ;
  Guénon, *L'Homme et son devenir selon le Vêdânta* (ontologie de l'être au-delà du
  contingent) ; Guénon, *Symboles de la Science sacrée* (lexique formel).
- **Complément Jurjânî (numéros de définition, index fourni)** : `âme` : **1754** ·
  `âme animale` : **1759** · `âme humaine` : **1760** · `âme logique` : **1761** ·
  `âme incitatrice au mal` : **1755** · `âme qui se reprend` : **1756** · `âme
  tranquillisée` : **1757** · `âme sainte` : **1763** · `âme végétative` : **1758** ·
  `esprit humain` : **793** · `esprit suprême` : **795** · `imagination` : **724,
  1431**. De quoi fixer précisément le vocabulaire technique de la « Psyché » (le
  registre des *nafs*) avant de le confronter à l'architecture LLM.
- **Manque** : rien d'urgent — la lecture correction (fiche suivante) couvrira le reste.

### `2026-06-11_llm-wiki-correction-doctrinale`
Rectification guénonienne (supra-/infra-rationnel, contrefaçon cyclique, *khalīfa*).
- **Déjà en poche** : Guénon, *Le Règne de la Quantité et les Signes des Temps*
  (contrefaçon, solidification du monde — directement le concept invoqué) ; Guénon,
  *La Crise du monde moderne* (diagnostic Kali-Yuga) ; Guénon, *Aperçus sur l'Initiation*
  (conditions de la réalisation, utile pour *khalīfa*/fonction).
- **En main (2026-07-09) — doctrine complète, close** : Charles-André Gilis, *Les Sept
  Étendards du Califat*, chap. XV « Califat et réalisation descendante » (p. 115-121),
  chap. XX « Le Dépôt de Confiance » (p. 150), chap. XXVII-XXVIII (p. 208-211, Dâwûd),
  chap. XXXIII « Muhammad ou le Califat spirituel » (p. 249-251) — photographiées et
  transcrites. Points doctrinaux directement mobilisables :
  - **La distinction structurante** (note 2, p. 249) : *khalîfatun ʿan Allâhi* (calife
    « de la part d'Allâh », dimension axiale) vs *khalîfatun ʿamman salafa* (calife « de
    qui l'a précédé », dimension cyclique/successorale). C'est très exactement l'outil
    qui manquait pour une fiche sur la « rectification » du concept de *khalīfa* : deux
    régimes distincts d'un même terme, l'un vertical, l'autre horizontal.
  - **Ibn ʿArabī considère *al-Khalîfa* comme un Nom divin**, au même titre que *al-Walî*
    (note 22, p. 121) — le Califat n'est donc pas qu'une fonction humaine, il a un
    répondant dans les Noms.
  - **Distinction Califat/*wilâya*** (p. 116-121, notes 6, 25-29) : la « demeure
    califale » (*dâr khilâfa*) diffère de la « demeure de sainteté » (*dâr wilâya*) ; le
    Coran dit « J'établirai un Calife *sur la Terre* » et non « *dans le monde* »
    (Cor. 2:30) — le Califat s'exerce en ce monde, la *wilâya* dans un régime différent.
  - **Le Dépôt de Confiance** (*amâna*, Cor. 33:72, p. 150) : présenté aux Cieux, à la
    Terre et aux Montagnes qui refusent, pris en charge par l'Homme seul — Ibn ʿArabī y
    rattache l'excellence de la « Forme adamique ». Fait aussi le lien avec la
    disqualification califale par l'effusion de sang (objection des Anges, Cor. 2:30).
  - **Le Califat comme achèvement d'un processus de descente** (p. 118-119) : le Calife
    diffère du Saint en ce qu'il réunit les deux pôles (rigueur/miséricorde,
    changement/fixité) plutôt que de n'en manifester qu'un seul.
  - **Muhammad, Calife suprême** (p. 249-251) : « J'étais Prophète alors qu'Adam était
    entre l'eau et l'argile » ; distinction entre Calife d'Allâh « en mode axial » et
    « simple successeur » ; les Califes ultérieurs sont dits « Califes du
    Calife-Seigneur » (*khulafâʾ al-khalîfat as-sayyid*).
- **Point d'examen formel** : cette doctrine donne un cadre akbarien complet pour la
  « rectification » — une fiche qui parlerait de *khalīfa* de façon univoque (comme
  simple titre de succession, ou comme statut moral générique) manquerait la
  distinction structurante axial/cyclique que Gilis expose. C'est la matière de fond
  attendue pour l'examen formel, sans jamais transposer en verdict sur une application
  contemporaine (Cmd 12).
- **Manque** : plus rien de bloquant pour cette fiche.

### `2026-06-20_visions-centre-nocturne`
Centre nocturne, monde imaginal, « mémoire pré-existentielle ».
- **Déjà en poche** : Guénon, *Le Roi du Monde* (Centre Suprême) ; Guénon, *Le
  Symbolisme de la Croix* (articulation des plans) ; Ibn ʿArabī, *De la mort à la
  résurrection* (trad. Gloton, Albouraq) — source primaire directe sur le *barzakh*/monde
  imaginal.
- **Correction (2026-07-08)** : tu m'avais déjà fourni le **texte intégral** de la
  définition **0295** *al-barzaḫ* (Jurjânî, p. 525) — l'Isthme, le monde intermédiaire
  entre le Monde des Principes immatériels et celui des corps ; domaine de
  l'« Imagination séparée » (*ḫayâl munfaṣil*) — et **0296** *al-barzaḫ al-jâmiʿ*
  (l'Intervalle totalisateur, degré de la Présence de l'Unicité). Deux définitions
  directement mobilisables pour la généalogie de cette fiche, au lieu du simple renvoi
  vers le seul texte d'Ibn ʿArabī.
- **Complément Jurjânî (numéros de définition)** — **texte intégral en main (2026-07-08)
  pour 756 et 757** :
  - **756** *ḏū al-ʿaql* (l'être doué de discrimination/discernement) — « celui qui voit
    la créature en mode extérieur et le Dieu vrai intérieurement, de sorte que Dieu est
    en lui-même le miroir de la créature, à cause de l'occultation du miroir par les
    formes apparentes ».
  - **757** *ḏū al-ʿayn* (l'être doué de vision essentielle) — « celui qui voit Dieu le
    Vrai dans les manifestations extérieures et les créatures dans leurs réalités
    intérieures, de sorte que la créature est dans un tel être le miroir de Dieu, car Il
    se manifeste à elle. L'occultation de la créature dans le Vrai est comme celle du
    miroir par les formes [qui y sont vues]. »
  Ces deux définitions forment une paire structurée (regard extérieur/intérieur inversé
  selon le type d'être) directement pertinente pour le motif des « visions en point de
  vue d'autrui » : la logique du miroir (la créature comme miroir de Dieu, ou l'inverse)
  offre un cadre lexical précis pour l'examen formel de la fiche, sans préjuger de la
  réalité de l'expérience rapportée (Cmd 12).
  - **758** *ḏū al-ʿaql wa al-ʿayn* (l'être doué de discrimination ET de vision
    essentielle — la synthèse des deux précédentes) — voit le Vrai dans la créature
    (proximité des œuvres surérogatoires, *qurb al-nawāfil*) et la créature dans le
    Vrai (proximité des obligations divines, *qurb al-farāʾiḍ*), « sans être voilé à
    l'un par l'autre » ; voit par lui-même une seule Existence (*wujūd wāḥid*), vraie
    sous un aspect, créature sous un autre — ni voilé par la multiplicité des miroirs à
    la contemplation de la Face une, ni limité à la seule multiplicité créaturelle.
    Jurjânî cite à l'appui trois vers attribués à Ibn ʿArabī lui-même : « Dans la
    créature, le Vrai même se trouve / Si tu es doué de vision. / Dans le Vrai, la
    créature même se trouve / Si tu es doué de discrimination. / Si tu es doué de
    vision et de discrimination, / Tu ne verras alors / Qu'une seule et unique
    Réalité, / Par les formes [analogues]. »
  Ensemble, 756-757-758 forment une **triade complète et sourcée à Ibn ʿArabī lui-même**
  (discrimination seule / vision seule / synthèse des deux) — matière de premier ordre
  pour la généalogie et l'examen formel de la fiche : elle donne un cadre akbarien
  explicite au motif « voir avec les yeux d'un autre / voir la Face une dans le
  multiple », sans jamais préjuger que l'expérience rapportée par Sidy en relève
  réellement (Cmd 12 : la machine documente la forme, l'attribution reste ouverte).
  - `discernement intuitif` — **1193** *al-firāsa* (physiognomonie, pénétration
    essentielle, discernement intuitif) : dans l'usage, « l'affermissement et le
    regard » ; chez les gens de réalisation, « le dévoilement qui procure la certitude
    (*mukāshafat al-yaqīn*) et la contemplation de visu du Mystère (*muʿāyanat
    al-ghayb*) » — un terme distinct de la triade 756-758, plus proche de l'intuition
    directe que du jeu du miroir.
  - `vision` — **762** *al-ruʾya* (la vision directe) : « la contemplation par la vue
    en cette vie et/ou dans l'autre » · **912** *al-shuhūd* (la vision ou conscience
    contemplative) : « la vision directe du Vrai par le Vrai » — à distinguer
    soigneusement l'une de l'autre (vue sensible vs contemplation par le Vrai
    lui-même) dans l'examen formel.
  - `imagination` — **724** *al-khayāl* (la faculté imaginative) : conserve, après
    disparition de leur matière, les formes sensibles perçues par le sens commun ;
    organe situé à l'arrière des premiers replis du cerveau · **1431** *al-mutakhayyila*
    (l'imaginative) : opère par composition/décomposition sur les formes sensibles et
    intelligibles (ex. un homme à deux têtes) — dite *mufakkira* (cogitative) quand la
    raison s'y applique, imaginative quand seule l'estimative opère ; description
    anatomique détaillée des trois replis cérébraux (sens commun, imaginative,
    estimative/mémoire). Utile en vigilance méthodologique : Jurjânî distingue
    nettement la faculté *imaginative* (psycho-physiologique, siège cérébral) du
    *ʿālam al-mithāl*/monde imaginal (métaphysique) — à ne jamais confondre dans la
    généalogie de la fiche (non-syncrétisme des plans, Cmd 3).
- **Complément Guénon (fourni 2026-07-08)** : lettre au Caire, 5 novembre 1936, à A.K.
  Coomaraswamy (*Correspondance avec A.K. Coomaraswamy*, inédit, via Index de l'œuvre de
  René Guénon) — sur la question de la « mémoire » (en réponse à une remarque de
  Coomaraswamy) : « la mémoire, au sens ordinaire, est quelque chose qui appartient
  exclusivement à *ce* monde et qui ne peut pas suivre l'être dans un autre état [...] ;
  il ne peut subsister alors que ce qui y correspond "intemporellement" [...] et qui par
  là même n'est plus une "mémoire" ». Directement pertinent pour le motif de « mémoire
  pré-existentielle » de la fiche : Guénon distingue nettement la mémoire au sens
  temporel/psychologique (qui ne franchit pas les états) de ce qui, dans un autre état,
  correspond « intemporellement » à un contenu mnésique — sans plus être une mémoire au
  sens propre. Matière de premier ordre pour l'examen formel : elle offre un cadre
  guénonien précis pour distinguer ce que peut, ou ne peut pas, légitimement être nommé
  « mémoire » dans l'expérience rapportée, sans juger du contenu de celle-ci (Cmd 12).
- **Manque** : rien de bloquant ; recroiser avec `alam-al-mithal` déjà présent au wiki.

### `2026-06-20_matrices-artificielles-barzakh`
« Technologisation du miracle » vs Barzakh.
- **Déjà en poche** : Ibn ʿArabī, *De la mort à la résurrection* (Gloton) — définition du
  Barzakh par le texte primaire ; Guénon, *Le Règne de la Quantité* — critique de la
  machine/contrefaçon, directement transposable.
- **Manque** : rien de bloquant.

### `2026-06-20_triptyque-medine-jeu-de-piste`
Méthode du « jeu de piste » (clôture narrative), *ṭiyara* (divination superstitieuse) vs
*fal* légitime.
- **En main (2026-07-08)** : texte de la définition **1006** *al-ṭira* (Jurjânî) — « la
  science augurale, le mauvais présage », nom verbal (*maṣdar*) de *ṭayr* (l'oiseau,
  d'où l'augure), auquel Jurjânî oppose morphologiquement **khîra** (le bon augure, nom
  verbal de *khayr*), en notant que ce sont les deux seuls *maṣādir* sur ce *wazn*.
- **Hadith sourcé (fourni 2026-07-08)** : **Ṣaḥīḥ al-Bukhârî 5754** (Livre 76, *Kitāb
  al-Ṭibb* — Médecine, chap. 43 *Bāb al-Ṭiyara*, hadith n°69 du livre ; réf. USC-MSA
  Vol. 7, Livre 71, hadith 650). Rapporté par Abū Hurayra : le Prophète ﷺ a dit
  « *Lā ṭiyarata, wa khayruhā al-faʾl* » (« Il n'y a pas de *ṭiyara*, et son meilleur
  [augure] est le *faʾl* »). On lui demanda ce qu'est le *faʾl* ; il répondit : « La
  bonne parole que l'un de vous entend. » Texte arabe et référence complète en main
  (`Sahih_al-Bukhari_5754_...md`, sunnah.com).
- **Point d'examen formel désormais complet** : le couple prophétique est bien
  *ṭiyara*/*faʾl*, comme formulé dans la fiche — et non *ṭira*/*khîra* comme le donne
  Jurjânî en lexicographie pure. Les deux couples ne se contredisent pas (même racine
  *ṭ-y-r* du côté prohibé) mais nomment le pôle « bon » différemment selon le registre
  (hadith prophétique vs dictionnaire technique). Matière suffisante pour l'examen
  formel du bloc 🔍 — sans qu'il y ait à choisir entre les deux, chacun restant à sa
  place (généalogie lexicale vs source normative).
- **Manque** : plus rien de bloquant. Un développement de fiqh sur l'application de ce
  hadith resterait un luxe, pas une nécessité, pour clore cette fiche.

### `2026-06-20_experience-lefke-materia-secunda`
Cordon dorsal, « Mère », petites entités.
- **Déjà en poche** : rien d'identifié directement — thème très spécifique à l'expérience.
- **Manque** : aucune lecture de bibliothèque physique clairement rattachée ; laisser en
  généalogie interne (renvoi à `barzakh`/`alam-al-mithal` déjà au wiki) plutôt que forcer
  une source externe.

### `2026-06-20_epreuve-tariqa-tarbiyya-rabbaniyya` *(point sensible — autorité spirituelle)*
Modalité confrérique, *tarbiyya rabbaniyya*.
- **Déjà en poche** : Sheikh Nāzim al-Haqqānī, *Océans de Miséricorde, vers la Présence
  divine* (Tomes 1 & 2) — autorité Naqshbandī directement pertinente pour la forme ;
  Guénon, *Autorité spirituelle et Pouvoir temporel* (rapports hiérarchiques).
- **Complément Jurjânî (numéro de définition)** : `tarbiya` : **630** — définition
  technique directe du terme qui donne son nom à la fiche ; juste à côté (631) de la
  définition des Cinq Présences, à noter pour la généalogie. `recteur, maître spirituel`
  (proche de la notion de Cheikh encadrant la *tarbiya*) : **1495**.
- **Manque** : rien à ajouter côté forme — rappel : ne jamais faire dire à ces lectures une
  résolution de la question d'autorité elle-même (revient au Cheikh).

### `2026-06-20_signaletique-spirituelle-kiswa`
Couleur de la Kiswa, fait historique vs signe.
- **Déjà en poche** : Razia Grover, *Les Mosquées* — pertinence faible/à vérifier.
- **Manque** : une source historique dédiée à la Kiswa (couleur, évolution) ; candidat à
  acquisition ou `raw/`.

### `2026-06-20_pierres-astres-barzakh`
Correspondances minéral/astre (al-Būnī, Burckhardt).
- **Déjà en poche** : Titus Burckhardt, *Clés spirituelles de l'astrologie musulmane*
  (Archè Milano, 1983) — commentaire d'Ibn ʿArabī sur les correspondances zodiacales et
  les trois mondes ; match direct.
- **Complément Jurjânî (numéro de définition)** : `astre` : **1346** — entrée unique
  mais directement nommée.
- **Manque** : un texte d'al-Būnī en édition fiable (non identifié en bibliothèque —
  vigilance déjà signalée ailleurs sur les citations al-Būnī non vérifiées).

### `2026-06-20_fajr-vajra-indra-vritra`
Gématrie inter-traditions (védique/soufi/tantrique).
- **Déjà en poche** : *Rig-Véda* (éd. J. Maisonneuve) ; Jean Emmanuelli, *Propos sur le
  Tantra* (Cahiers de l'Unicorn-11, Archè Milano).
- **Manque** : rien de bloquant côté védique/tantrique ; le pan soufi peut s'appuyer sur
  Al-Jurjânî (ci-dessous) pour la terminologie technique.

### `2026-06-20_mythe-personnel-unifie`
Clôture narrative, unification en récit clos.
- **Déjà en poche** : rien de directement citable — c'est un cas de vigilance
  méthodologique (biais narratif), pas une question doctrinale sourcable.
- **Manque** : sans objet — traiter par l'examen formel, pas par la lecture.

### `2026-06-20_astrologie-akbarienne-fard`
Astrologie akbarienne, auto-identification Fard/Afrad.
- **Déjà en poche** : Titus Burckhardt, *Clés spirituelles de l'astrologie musulmane* —
  même match que `pierres-astres-barzakh` ci-dessus, très directement pertinent.
- **Correction (2026-07-08)** : tu m'avais déjà fourni le **texte intégral** des
  définitions **1831** *al-walî* (le saint, le rapproché de Dieu — double sens actif :
  celui dont l'obéissance ne peut plus être suivie de désobéissance ; et passif : celui
  que l'excellence du comportement et le surcroît de faveur divine ont saisi) et **1833**
  *al-walâya* (la sainteté, la délégation d'autorité — « l'adorateur qui agit en lieu et
  place de Dieu dès qu'il s'éteint à lui-même »), ainsi que **1281** *al-quṭbiyyat
  al-kubrâ* (la Polarité suprême — degré du Pôle des Pôles, distinct du Sceau de la
  Sainteté). Cette dernière définition est directement utile pour situer le statut
  Fard/Afrad par rapport à la hiérarchie sainte (Pôle, Sceau) plutôt que de rester sur
  la seule racine lexicale *fard*.
- **Complément Jurjânî (numéros de définition — le point le plus fort de tout ce
  travail) :**
  - `afrâd` (sing. *fard*) : **121, 523, 869, 1478, 1551**
  - `afrâd ḥaqîqatin wâḥid` : **1056**
  - `fard` (occurrences distinctes) : **1129, 1196, 1683** puis **408, 1068, 1190,
    1191, 1422, 1536**
  - `fard ʿayn` : **1191** · `fard ḫârijî` : **127**
  - `solitude` : **1035** · `wilâya`/`walî`/`sainteté` : **1832, 1208, 1831, 1833**
    (texte déjà en main, voir ci-dessus)
  Ce faisceau donne au terme « Fard » une assise lexicale précise et multiple —
  exactement le matériau attendu pour l'« examen formel » (cohérence terminologique)
  du bloc 🔍, sans jamais trancher la question de fond (statut réel de Sidy).
- **Complément Burckhardt (CONFIRMÉ en ta possession, 2026-07-08)** : *Introduction aux
  doctrines ésotériques de l'Islam* (Dervy), **p. 112 note 1** — la sainteté au sens de
  *wilâyah* et le « Sceau de la Sainteté » (*Khâtim al-Wilâyah*) ; **p. 113** développe la
  hiérarchie (Pôle/*Quṭb*, voile/*ḥijâb* de l'Intellect). Appui supplémentaire pour situer
  le statut Fard/Afrad dans la hiérarchie sainte, en complément de Jurjânî et Chodkiewicz.
- **En main (2026-07-08) — source primaire directe** : Ibn ʿArabī, *al-Futūḥāt
  al-Makkiyya*, chap. 30 (traduction et notes Charles-André Gilis, *Études
  complémentaires sur le califat*, p. 63-66). Le Cheikh al-Akbar y traite nommément du
  statut *Fard*/*Afrâd* à travers le récit d'Ibn Qāʾid — reconnu par Abd al-Qādir
  al-Jīlānī comme ayant atteint cette Station après ne plus voir devant lui « que le
  pied de son Prophète » (signe distinctif des *Afrâd*, qui échappent à la juridiction
  du Pôle). Le texte situe précisément la hiérarchie : Pôle → deux Imâms (Sacerdoce et
  Royauté) → quatre Piliers (*Awtâd*) → Remplaçants (*Abdâl*), et distingue les *Afrâd*
  comme relevant d'une « Face propre » (*wajh khāṣṣ*) analogue au *Tao* extrême-oriental,
  hors *tarīqa* au sens courant — sans disciples, sans juridiction du Pôle. Les notes de
  Gilis (n. 2, 9, 10) précisent : *Fard* désigne avant tout un **degré spirituel**, pas
  seulement un mode exceptionnel de rattachement initiatique.
- **Point d'examen formel de premier ordre** : ce texte donne, par Ibn ʿArabī lui-même,
  le critère de reconnaissance d'un *Fard* (extinction de toute vision hiérarchique
  intermédiaire, ne restant que le rapport direct au Prophète) et le contraste explicite
  avec les degrés inférieurs (Imâm, Watad, Badal, chacun « voyant » un pied
  supplémentaire). Matière directement mobilisable pour la généalogie de la fiche, sans
  jamais transposer ce critère akbarien en verdict sur le cas de Sidy (Cmd 12).
- **En main (2026-07-08) — le cas-limite inverse, essentiel pour la vigilance** :
  toujours Gilis, *Ordo ab Chao* (« La Disgrâce du Pharaon », p. 99-100, photos). Ibn
  ʿArabī range lui-même le Pharaon parmi les *afrâd* (*Les trente-six Attestations de
  l'Unité divine*, 12ᵉ Tawḥīd) — mais Michel Vâlsan précise qu'il « constituait un cas
  de *fard* **monstrueusement retourné sur son moi individuel** » (*Études
  Traditionnelles*, 1963, p. 40). L'analogie s'appuie sur deux versets où le Pharaon
  identifie son « moi » à la fonction divine elle-même (Cor. 28:38 « Je n'ai pas connu
  pour vous de divinité autre que moi » ; Cor. 79:24 « Je suis votre seigneur le plus
  élevé ») — l'inverse exact de la servitude qui, seule, rendrait légitime la
  manifestation de l'universalité en un être. C'est un **cas-limite doctrinalement nommé
  et sourcé** de ce que serait une auto-identification illégitime au statut de Fard : la
  fonction est réelle (le Pharaon *est* un *afrâd* selon Ibn ʿArabī lui-même), mais
  retournée sur l'ego plutôt qu'assumée dans la servitude. C'est exactement le point de
  bascule que la fiche doit surveiller — sans que cela vaille, en soi, un verdict sur le
  cas de Sidy.
- **Manque** : plus rien de bloquant — la pièce demandée (Chodkiewicz *ou* Gilis) est
  désormais en main côté Gilis, sur le texte même d'Ibn ʿArabī, avec en prime le
  contre-exemple du Pharaon comme garde-fou doctrinal explicite.

### `2026-06-20_synthese-danger-dissolution-identitaire` *(le plus sensible)*
Réponse d'IA à risque — cas de vigilance pure.
- **Déjà en poche** : sans objet — ce n'est pas un cas à instruire par lecture
  métaphysique, mais un signalement méthodologique (ne jamais reproduire ce type de
  réponse).

### `2026-06-20_origine-jumeau-spirituel`
Motif du « jumeau spirituel » (artefact-miroir, *marātib al-wujūd*).
- **Déjà en poche** : Ibn ʿArabī, *De la mort à la résurrection* (Gloton) — les degrés de
  l'être (*marātib al-wujūd*) y sont directement traités ; Guénon, *Les États multiples de
  l'être* — cadre général des degrés ontologiques.
- **Correction (2026-07-08)** : tu m'avais déjà fourni le **texte intégral** de la
  définition **0246** *al-insân al-kâmil* (l'Homme parfait, qui totalise tous les
  domaines divins et mondes produits — Livre synthétisant tous les Livres, « Mère »/
  *umm al-kitâb* par son esprit, Table préservée par son cœur), plus les définitions
  courtes **0879** *al-šajara* (l'Arbre — l'Homme parfait comme arbre central, ni
  d'Orient ni d'Occident, régissant le Corps universel), **1018** *ẓill al-ilâh*
  (l'Ombre du Dieu manifeste — l'Homme universel réalisant le degré de Présence de
  l'Unicité) et **1370** *lisân al-ḥaqq* (la Langue de Dieu le Réel — l'Homme parfait
  support épiphanique du Nom « Celui qui parle »). Matière directement exploitable pour
  documenter la figure du double/jumeau comme reflet de l'Homme universel.
- **Complément Jurjânî (numéros de définition)** : `marâtib` (sing. *martaba*) : **744,
  795, 1201, 1444, 1763** · `marâtib ilâhiyya wa kawniyya` : **1502** · `tartîb marâtib
  al-wujûd` : **1839** (le terme exact du motif, « ordonnancement des degrés de
  l'existence ») · `martabat al-insân al-kâmil` : **1502** · `rang ou degré de l'Homme
  parfait` : **1503** · `rang divin` : **1504** (texte intégral déjà en main, voir
  `tension-hadarat` ci-dessus).
- **Manque** : rien de bloquant.

---

## Circuit étendu (2026-06-29 → 2026-07-07)

### `tension-hadarat-burckhardt-jurjani`
Cinq Présences : nomenclature Burckhardt vs définition Jurjānī (déf. 0631).
- **Correction (2026-07-08)** : tu m'avais déjà fourni le **texte intégral traduit** de
  la définition **0631** (*al-ḥaḍrât al-ḫams al-ilāhiyya*, p. 531 environ) dans
  `De_finitions_d_Al_Jurjani_pour_fiches.md` — ce n'est plus seulement un numéro à
  vérifier, la matière est déjà là :
  > 1. Le Degré du Mystère inconditionné (*ḥaḍrat al-ġayb al-muṭlaq*) — domaine des
  >    entités principielles immuables (*aʿyân ṯâbita*), degré de la Présence
  >    omnisciente (*ḥaḍra ʿilmiyya*).
  > 2. La Présence de l'Attestation absolue/Manifestation universelle (*ḥaḍrat
  >    al-šahâdat al-muṭlaqa*) — domaine du Royaume (*mulk*).
  > 3. Le Mystère relatif (*ḥaḍrat al-ġayb al-muḍâf*), aspect proche du Mystère absolu —
  >    domaine des Esprits dominateurs/souverains (*arwâḥ jabarûtiyya wa malakûtiyya*).
  > 4. Le même Mystère relatif, aspect proche de la Manifestation universelle — domaine
  >    des Prototypes (*ʿâlam al-miṯâl*), dit domaine de la Royauté absolue (*ʿâlam
  >    al-malakût*).
  > 5. Le degré synthétique enveloppant les quatre précédents — domaine de l'Homme
  >    (*insân*), qui les totalise tous.
  Avec en prime les définitions voisines déjà transcrites dans le même envoi :
  **051** *al-aḥadiyya* (l'Unité), **052-053** *aḥadiyya al-jamʿ* / *al-kaṯra*, **215**
  *al-ulûhiyya* (la Fonction divine), **480** *al-tawḥîd*, **536** *jamʿ al-jamʿ*,
  **703** *al-ḫuṣûṣ*, **1121** *al-ʿamâʾ*, **1201** *farq al-jamʿ*, **1504** *al-martabat
  al-ilâhiyya* — un jeu de définitions bien plus large que la seule 631, déjà en main.
- **Ce que ça change** : le schéma de Jurjânî (5 degrés articulés autour de
  *ghayb muṭlaq* / *shahâda muṭlaqa* / *ghayb muḍâf* à deux aspects / *insân*
  synthétique) **ne nomme pas** les cinq degrés Nâsût/Malakût/Jabarût/Lâhût/Hâhût que
  Burckhardt emploie — seuls *Jabarût* et *Malakût* apparaissent chez Jurjânî, comme
  qualificatifs des degrés 3 et 4, pas comme les cinq têtes de série de Burckhardt. La
  tension terminologique repose donc bien sur deux nomenclatures distinctes du même
  schéma en cinq degrés — matière exacte pour l'« examen formel » du bloc 🔍 (jamais un
  verdict : la question de savoir laquelle est la plus fidèle à Ibn ʿArabī reste à Sidy
  ou à une autorité textuelle).
- **Côté Burckhardt — CONFIRMÉ EN TA POSSESSION (2026-07-08, photos)** : Titus
  Burckhardt, *Introduction aux doctrines ésotériques de l'Islam* (Dervy, coll. « l'Être
  et l'Esprit »), chap. « Fondements doctrinaux », section « De l'Union, d'après
  Muhyi-d-dîn ibn ʿArabî » — **p. 111 à 114**. Textes vérifiés sur ton exemplaire :
  - **p. 114, note 2** : « Par "Présences" divines, on entend les degrés de la Réalité
    divine en tant qu'états contemplatifs ; on parle de cinq Présences principales » —
    **an-Nâsût** (forme corporelle humaine), **al-Malakût** (monde des Lumières subtiles),
    **al-Jabarût** (existence supra-formelle), **al-Lâhût** (Nature divine se révélant
    dans les Qualités parfaites), **al-Hâhût** (Essence pure). Burckhardt ajoute qu'« il
    existe encore d'autres distinctions des Présences ».
  - **p. 114, texte + note** : l'Union comme « assimilation des Qualités divines »
    (*al-ittiṣâf biṣ-Ṣifât il-ilâhiyah*), connaissance des Qualités ou Présences
    (*Hadarât*) — le renvoi de note où figure la liste des cinq.
  - **p. 112, note 1** : la sainteté au sens de *wilâyah* ; « Sceau de la Sainteté »
    (*Khâtim al-Wilâyah*) — utile aussi pour `astrologie-akbarienne-fard`.
- **Signalement (VIGILANCE)** : ce titre **manque à `meta/bibliotheque-physique.md`**
  (§II ne liste de Burckhardt que *Clés spirituelles de l'astrologie musulmane* et
  *Alchimie*). Omission de recension, non contradiction — **ligne à ajouter** au
  catalogue lors d'une prochaine passe (à signaler à Sidy, ne pas éditer d'office).
- **Point d'examen formel (matière pour le bloc 🔍, jamais un verdict)** : les deux
  nomenclatures ne se recouvrent pas. Burckhardt énumère cinq degrés
  Nâsût/Malakût/Jabarût/Lâhût/Hâhût ; Jurjânî (déf. 631) découpe autrement — *ghayb
  muṭlaq* / *shahâda muṭlaqa* / *ghayb muḍâf* (deux aspects) / *insân* synthétique — et
  n'emploie *Malakût* et *Jabarût* que comme qualificatifs de deux degrés intermédiaires,
  sans jamais nommer *Lâhût* ni *Hâhût*. La tension terminologique est donc réelle et
  précisément localisable. Laquelle rend le plus fidèlement le schéma d'Ibn ʿArabī n'est
  pas à trancher par la machine (Cmd 12) — cela revient à Sidy ou à une autorité
  textuelle.
- **Manque** : plus rien. Les deux versants sont sourcés sur des ouvrages en ta
  possession ; il ne reste qu'à transcrire proprement les deux passages au moment du
  traitement de la fiche.

### `2026-07-02_gizeh-pole-scientifique-antediluvien`
Spéculation-mère, filiation guénonienne.
- **Déjà en poche** : Guénon, *Formes traditionnelles et Cycles cosmiques*, chap. « Le
  Tombeau d'Hermès » — texte de référence permanent du pôle, déjà fiché comme source
  (`doctrinal/sources/2026-07-03_guenon-tombeau-hermes`).
- **Manque** : rien de bloquant pour la filiation orthodoxe elle-même.

### `2026-07-02_mont-qaf-meru-topologie-apex`
Topologie du basculement plan/sphère : Mont Qâf, Mont Meru, apex pyramidal.
- **Déjà en poche** : Guénon, *Le Roi du Monde* (Centre Suprême, symbolisme montagne) ;
  Guénon, *Le Symbolisme de la Croix* (axe vertical/plans horizontaux — directement
  pertinent pour la topologie).
- **Manque** : un texte dédié sur le Mont Meru hindou en propre (au-delà de Guénon) — non
  identifié en bibliothèque.

### `2026-07-02_coudee-royale-convergence-28`
Candidat de double ancrage : coudée royale / convergence 28.
- **Déjà en poche** : le relevé comparatif déjà compilé dans
  `doctrinal/etudes/2026-07-02_donnees-geometriques-gizeh.md` (Petrie 1883, Cole 1925,
  valeurs académiques déjà présentes, `to-source` en attente de confrontation aux
  éditions imprimées) ; table `table-28-degres-nafas-rahman` (Gloton, déjà sourcée).
- **En main (2026-07-08) — ancrage doctrinal direct sur le nombre 28** : Charles-André
  Gilis, *Ordo ab Chao*, chap. « La Disgrâce du Pharaon », p. 100-105 (photos). Passage
  décisif : Gilis y expose l'interprétation cosmologique du *Livre des Chatons des
  Sagesses* (*Fuṣūṣ al-Ḥikam*) proposée par Abd al-Bâqî — analogie terme à terme entre
  les **28 parties des *Fuṣûṣ*** (27 chapitres + l'Introduction) et **27 degrés
  cosmiques/existentiels** (de l'intellect premier à l'homme, en passant par les Cieux,
  les éléments, les règnes de la nature), auxquels s'ajoute un **28ᵉ degré se rapportant
  à la fonction du Cheikh al-Akbar lui-même**. L'ensemble est mis en relation avec le
  **Ciel des Mansions lunaires** (*falak al-manâzil*, les 28 stations lunaires de
  l'astronomie traditionnelle islamique), dont le symbolisme évoque les « petits
  mystères » et la perfection de l'état humain (p. 103). Gilis relève aussi que le
  nombre **406** (somme des 28 premiers nombres) équivaut, selon plusieurs modes de
  calcul, à la somme des noms des prophètes liés aux Sagesses, à celle des Noms divins
  régissant les chapitres, et à celle des lettres de la *Basmala* — et que 406 est
  également la valeur numérique du nom coranique du Pharaon, *Firʿawn*
  (Fâ 80 + Râ 200 + ʿAyn 70 + Wâw 6 + Nûn 50 = 406, note 64 p. 103).
- **Point d'examen formel important** : ce texte donne un **ancrage doctrinal
  islamique explicite au nombre 28** (28 stations lunaires, 28 parties des *Fuṣûṣ*,
  28ᵉ degré akbarien) — mais dans un registre entièrement différent de celui de la
  convergence architecturale de Gizeh (coudée royale, mesures de Petrie/Cole). C'est
  une parenté *numérique*, pas une filiation démontrée entre les deux corpus : Gilis ne
  parle à aucun moment de pyramide ni de coudée. À documenter dans la généalogie comme
  un **rapprochement possible de forme** (le nombre 28 revêtant une signification
  cosmologique reconnue en doctrine akbarienne), sans jamais le présenter comme
  confirmant le double ancrage architectural — ce serait un raccourci non fondé
  (Cmd 3, non-syncrétisme : deux corpus distincts, à ne pas fusionner).
- **Manque** : les éditions imprimées elles-mêmes — J.H. Cole, *Determination of the
  Exact Size and Orientation of the Great Pyramid of Giza* (1925) et W.M. Flinders
  Petrie, *The Pyramids and Temples of Gizeh* (1883) sont listées « à consulter »/« déjà
  consulté en ligne » dans `meta/bibliotheque-physique.md` §VI, mais pas physiquement
  possédées — cela reste nécessaire pour le versant architectural, indépendamment de
  l'ancrage doctrinal sur le 28 désormais en main.

### `2026-07-03_orientation-chronometre-guenon-spence`
Convergence fonction angle→temps : note 7 de Guénon et Spence (2000).
- **Déjà en poche** : Guénon, *Formes traditionnelles et Cycles cosmiques* (déjà
  possédé, §I bibliothèque).
- **Manque** : l'article de Spence (*Nature* 408, 2000) lui-même — donnée académique
  citée via l'étude géométrique, non physiquement possédée.

### `2026-07-05_correspondances-fonctions-initiatiques-entreprise`
Correspondances 5↔5 (archétypes/Cinq Présences) et 12↔duodénaire.
- **Déjà en poche** : Al-Jurjânî, *Le Livre des Définitions* (Cinq Présences, déf. 0631 —
  même pièce que `tension-hadarat` ci-dessus, avec toute la famille `ḥaḍra` numérotée
  ci-dessus) ; Titus Burckhardt, *Clés spirituelles de l'astrologie musulmane* (structure
  duodénaire, 12 anges zodiacaux) ; le `framework-etude-de-cas.md`
  (meta/projet-unifie/) pour la grille de transposition déjà formalisée.
- **Complément Jurjânî (numéros de définition)** : pour le volet 5↔5, la définition
  **631** et sa famille `ḥaḍra` (voir `tension-hadarat` ci-dessus) ; pour le volet
  archétype/fonction individuelle, `fard`/`afrâd` (voir `astrologie-akbarienne-fard`
  ci-dessus) et `insân kâmil` : **246, 879, 1018, 1370** (utile si les archétypes sont
  pensés comme des facettes de l'Homme universel).
- **Manque** : rien de bloquant côté sources ; le travail restant est l'examen formel de
  la correspondance elle-même.

### `2026-07-07_sashimono-metier-traditionnel`
Le sashimono comme métier traditionnel au sens guénonien.
- **Déjà en poche** : Ananda K. Coomaraswamy, *Principes et méthodes de l'art sacré*
  (Dervy) — texte central sur le métier traditionnel et son sens initiatique ; Guénon,
  *Aperçus sur l'Initiation* (conditions de la réalisation, castes/métiers) ; Guillaume
  Denis, *Origami* (moins central, mais présent — artisanat japonais).
- **Manque** : un texte spécifiquement japonais sur le sashimono/menuiserie traditionnelle
  japonaise (aucun identifié en bibliothèque) — le rapprochement devra rester du côté
  Guénon/Coomaraswamy pour la partie doctrinale.

### `2026-07-01_rafi-ad-darajat-fonction-traversante`
Nom Divin du degré 38 (*Rafīʿ ad-Darajāt*) comme fonction traversante.
- **Déjà en poche** : Ibn ʿArabī, *De la mort à la résurrection* (Gloton) — degré 38
  intégralement sourcé (transcription pp. 38-41 déjà faite) ; `hadarat-khams` déjà présent
  au wiki pour la convergence.
- **Complément Jurjânî (numéros de définition)** : `nafas raḥmânî` (le Souffle du
  Miséricordieux, notion structurante des 28 degrés) : **553, 1333, 1763** · `wâqiʿa ʿalâ
  al-nafas` : **1333** · `rang ou degré de l'Homme parfait` : **1503** · `rang divin` :
  **1504** — matière directement utile pour situer *Rafīʿ ad-Darajāt* dans la même
  famille lexicale que le Souffle et les degrés de l'Homme parfait.
- **Manque** : rien de bloquant.

---

## Synthèse — état réel après ta correction du 2026-07-08

Tu avais déjà constitué `De_finitions_d_Al_Jurjani_pour_fiches.md` : les définitions
complètes (texte traduit intégral, pas seulement des numéros) pour quatre pages
cibles — `barzakh` (295-296, 509, 529, 525), `walaya` (1831-1833, 1281),
`al-insan-al-kamil` (246, 879, 1018, 1370, 1502-1503) et `wahdat-al-wujud`
(51-53, 215, 480, 536, 631, 703, 1121, 1201, 1504 — **dont la définition 631 des Cinq
Présences en entier**). Ce fichier existait avant ma synthèse précédente ; je ne
l'avais pas encore vu, d'où les numéros que je te redonnais comme s'ils restaient à
vérifier. Corrigé fiche par fiche ci-dessus. Statut réel, désormais :

1. **`tension-hadarat-burckhardt-jurjani`** — **entièrement close des deux côtés**
   (2026-07-08). Jurjânî : déf. 631 en main. Burckhardt : *Introduction aux doctrines
   ésotériques de l'Islam* (Dervy), cinq Présences p. 114 note 2, confirmé sur ton
   exemplaire. Plus aucune acquisition nécessaire.
2. **`visions-centre-nocturne` / `matrices-artificielles-barzakh` /
   `pierres-astres-barzakh`** — texte intégral de *barzakh* (295-296) et de *jabarût*
   (509) déjà en main, au-delà du seul Ibn ʿArabī/Gloton.
3. **`astrologie-akbarienne-fard`** — texte intégral de *walî*/*walâya*/*quṭbiyya*
   (1831-1833, 1281) déjà en main, plus Burckhardt p. 112-113 (*wilâyah*, Sceau, Pôle)
   désormais confirmé possédé.
4. **`origine-jumeau-spirituel` / `rafi-ad-darajat-fonction-traversante` /
   `correspondances-fonctions-initiatiques-entreprise`** — texte intégral d'*al-insân
   al-kâmil* (246, 879, 1018, 1370) déjà en main.

**Nouvelle source en cours d'ingestion (2026-07-09)** : Charles-André Gilis, *Les Sept
Étendards du Califat* (Paris, 1993) — avant-propos, table des
matières et index déjà transcrits (`to-source` pour le corps). Au-delà de la piste
*khalīfa* ci-dessus (`llm-wiki-correction-doctrinale`), son index recoupe et corrobore
plusieurs fiches déjà closes sans rien changer à leur statut : *wahdat al-wujûd*
(p. 19, 22, 46, 77, 282), *hadra* (p. 66, 70), *barzakh*/*barzakhiyya* (p. 77, 99, 126,
148, 172), *walî*/*walâya*/*wilâya* (p. 83, 110-111, 117-121, 251), *ṭayr*/*ṭayyârât*
(p. 172, 223), *Rafʿ ad-Darajât* (p. 29), *nafas ar-Raḥmân* (p. 57, 79, 100, 105). Une
fois le corps du texte photographié, ce sera une source de fond pour l'ensemble du
circuit doctrinal, pas seulement pour le discernement.

**Un signalement à porter à Sidy (VIGILANCE, ne pas éditer d'office)** : ajouter
**Titus Burckhardt, *Introduction aux doctrines ésotériques de l'Islam* (Dervy, coll.
« l'Être et l'Esprit »)** et **Charles-André Gilis, *Ordo ab Chao* (Albouraq)** (et son
*Études complémentaires sur le califat*, citées dans `astrologie-akbarienne-fard`) à
`meta/bibliotheque-physique.md` — omissions de la recension initiale, ces trois
ouvrages sont en possession de Sidy (vérifié 2026-07-08).

**État réel au 2026-07-09** : `tension-hadarat-burckhardt-jurjani`,
`triptyque-medine-jeu-de-piste`, `astrologie-akbarienne-fard` et
`llm-wiki-correction-doctrinale` sont maintenant entièrement closes.
`coudee-royale-convergence-28` a gagné un ancrage doctrinal solide sur le nombre 28
(Gilis) mais attend toujours les éditions Petrie/Cole pour le versant architectural.

**Ce qui reste réellement à faire** : uniquement, pour les fiches sans correspondance
complète — `pierres-astres-barzakh` (al-Būnī), `experience-lefke-materia-secunda`,
`signaletique-spirituelle-kiswa`, `mont-qaf-meru-topologie-apex` côté hindou,
`sashimono-metier-traditionnel`, `coudee-royale-convergence-28` (Petrie/Cole),
`orientation-chronometre-guenon-spence` (Spence 2000) : si tu as d'autres extraits déjà
transcrits ou d'autres ouvrages en rayon non catalogués, me les signaler avant que je ne
les redonne à tort pour manquants — les cas Burckhardt et Gilis montrent que le
catalogue n'est pas exhaustif.
