# MASTER-UPDATES — Lot « Générateur de manifeste » (2026-07-01)

> Lot produit par Claude.ai (session A3 — Développement Instrument, 2026-07-01).
> Phase 1 de la feuille de route : spec + script déterministe + données v0.1.
> Testé en bac à sable avant livraison (cas nominal 8 nœuds / 2 ancrages ✓ ;
> validations bloquantes ✓ : correctif waswâs/Qliphoth et Cmd 5 refusent bien).

## 1. Fichiers du lot, par dossier

### atelier/projets/
- `spec-generateur-manifeste.md` — spécification (fiche projet, frontmatter atelier).
- `generer-manifeste.py` — le script. Après rangement : `chmod +x atelier/projets/generer-manifeste.py`.
- `instrument-donnees.yaml` — déclaration applicative v0.1 (8 nœuds Tasawwuf,
  2 ancrages établis de la convergence des 28).

Aucun fichier ne touche `doctrinal/` : le lot est intégralement côté atelier,
liens à sens unique vers `doctrinal/` (étanchéité respectée par construction).

## 2. Ajouts à `doctrinal/index.md`

Aucun — l'index catalogue le circuit doctrinal ; ce lot est un lot atelier/projets.
(Si une section atelier/projets existe dans l'index, y ajouter :
`[[atelier/projets/spec-generateur-manifeste|Spécification du générateur de manifeste]]`.)

## 3. Entrée pour `annales.md` (une seule, préférence Sidy 2026-06-28)

```
## [2026-07-01] creation | Générateur de manifeste (Phase 1 Instrument) — spec + script + données v0.1
Lot atelier/projets : spécification du générateur déterministe wiki → wiki-manifest.json
(schéma v0.2.1), script generer-manifeste.py (testé en bac à sable, validations
bloquantes vérifiées), instrument-donnees.yaml v0.1 (8 nœuds Tasawwuf, convergence
des 28 inscrite comme premiers ancrages établis, sourcés Futūḥāt ch. 198 via
ibn-arabi-de-la-mort-a-la-resurrection-gloton). Arbitrages Phase 0 actés en session :
Three.js/WebGL, web mobile d'abord, hébergement statique.
```

## 4. Action côté serveur après rangement (facultatif mais recommandé)

Vérifier la dépendance puis générer un premier manifeste réel :
```bash
apt install -y python3-yaml   # si absent
python3 atelier/projets/generer-manifeste.py --repo /root/wiki
```
Le script est en LECTURE SEULE sur `doctrinal/` ; il n'écrit que
`atelier/projets/wiki-manifest.json`. S'il sort des erreurs, les rapporter à Sidy
sans corriger d'office (règle VIGILANCE).

## 5. Points sensibles

- **Évolution de périmètre validée en session** : le fichier déclaratif prévu
  (`ancrages.yaml`) est devenu `instrument-donnees.yaml` (nœuds + degrés + ancrages),
  car `degre_vertical` et l'appartenance aux arbres ne peuvent pas vivre dans le
  Sceau Recteur (étanchéité doctrinal ↛ app).
- **`nafas-rahmani` est un stub** (`#stub` à l'index) : le nœud est déclaré, le
  générateur passera, mais la fiche reste à développer (backlog §E).
- Le premier run réel du script sur `/root/wiki` peut révéler des écarts de slugs
  entre ce lot et les fiches réelles (produites de mémoire de l'index) — c'est
  précisément ce que les validations bloquantes attraperont ; corriger alors les
  chemins dans `instrument-donnees.yaml`, jamais les fiches.

## 6. Liens à vérifier à l'intégration

- `doctrinal/sources/ibn-arabi-de-la-mort-a-la-resurrection-gloton` (source des 2 ancrages).
- Les 8 fiches nœuds : hadarat-khams, wahdat-al-wujud, barzakh, walaya,
  al-insan-al-kamil, table-28-degres-nafas-rahman, manazil-al-qamar, nafas-rahmani.
- La fiche architecture v0.2 référencée dans `links` de la spec
  (`instrument-tradition-primordiale-architecture-v0.2`).

## 7. Documents amont à mettre à jour (vigilance documentaire, roadmap §5)

À la prochaine révision de `meta/projet-unifie/` :
- `02-instrument-feuille-de-route.md` : Phase 0 tranchée (Three.js / web mobile /
  statique) ; Phase 1 livrée (ce lot).
- `04-sessions-par-fonction-et-backlogs.md` §B : clore les trois questions [App]
  correspondantes ; ajouter « peupler degre_vertical (Phase 2) » au backlog.
