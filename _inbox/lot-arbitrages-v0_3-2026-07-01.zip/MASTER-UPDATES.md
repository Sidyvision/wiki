# MASTER-UPDATES — Lot « Arbitrages §8 + architecture v0.3 » (2026-07-01)

> Lot produit par Claude.ai (session A3, suite). Consigne les cinq arbitrages rendus
> par Sidy le 2026-07-01 sur les questions ouvertes de l'Instrument, et applique la
> convention `degre_vertical`. Le yaml v0.2 a été validé mécaniquement au générateur
> (8 nœuds / 2 ancrages, barzakh = 19.5, 0 erreur).

## 1. Fichiers du lot, par dossier

### atelier/projets/
- `instrument-tradition-primordiale-architecture-v0_3.md` — **nouvelle fiche
  canonique** de l'architecture. Les v0.1 et v0.2 restent au dépôt comme jalons,
  sans modification.
- `instrument-donnees.yaml` — v0.2, **remplace** la v0.1 du lot précédent
  (même chemin) : convention `degre_vertical` appliquée (barzakh 19.5, autres
  nœuds null commentés traversant/structurant).

## 2. Éditions ciblées à appliquer (le serveur applique, ne rédige pas)

### 2a. `meta/projet-unifie/02-instrument-feuille-de-route.md`
- Frontmatter : `updated: 2026-07-01`.
- §2 Phase 0 : marquer les trois décisions **actées (2026-07-01)** — moteur
  Three.js/WebGL ; cible web mobile d'abord (Safari iPad, statique) ; format
  `wiki-manifest` spécifié et générateur livré (Phase 1 close :
  `atelier/projets/spec-generateur-manifeste.md`, `generer-manifeste.py`,
  `instrument-donnees.yaml`).
- §2 Phase 4 : ajouter la note « **Méthode validée (2026-07-01)** : la vigilance
  apophatique se pratique en continu dès maintenant, parallèlement à toutes les
  phases (architecture v0.3 §5/§8) ; la Phase 4 ne conserve que la réalisation de
  l'onglet lui-même. »
- §2 Phase 5, question §8.2 : remplacer « à arbitrer par Sidy » par « **TRANCHÉ
  (2026-07-01)** : quatre angles AS/DS/MC/FC à qualités élémentaires ; appariement
  qualité ↔ angle `to-source` (schéma manuscrit) — voir architecture v0.3 §8. »
- §3 : marquer les questions moteur / cible / hébergement / génération comme
  **tranchées**, renvoi architecture v0.3 §8.
- Note d'en-tête : la fiche canonique devient
  `atelier/projets/instrument-tradition-primordiale-architecture-v0.3.md`
  (v0.2 conservée comme jalon).

### 2b. `meta/projet-unifie/04-sessions-par-fonction-et-backlogs.md`
- Frontmatter : `updated: 2026-07-01`.
- §B : clore les questions [App] moteur de rendu, format wiki-manifest, cible,
  génération du manifeste (toutes tranchées 2026-07-01, renvoi v0.3 §8) ; clore la
  question §8.2 (quatre angles). Ajouter deux items :
  « **[App]** Compléter les colonnes des degrés 21-23 / 25-27 de
  `table-28-degres-nafas-rahman` (photos Gloton ≈ pp. 40-44 attendues de Sidy) puis
  générer les 38 nœuds-degrés dans `instrument-donnees.yaml`. » et
  « **[App]** Valider le rendu d'Al-Insān al-Kāmil (proposition filament, v0.3 §7) ;
  transcrire l'appariement qualité ↔ angle depuis le schéma manuscrit (`to-source`). »

## 3. Ajouts à `doctrinal/index.md`

Aucun (lot intégralement atelier/meta).

## 4. Entrée pour `annales.md` (une seule)

```
## [2026-07-01] revision | Architecture Instrument v0.3 — arbitrages §8 et convention des degrés
Cinq arbitrages de Sidy consignés : lentille barzakh validée ; directions horizontales
tranchées (quatre angles AS/DS/MC/FC à qualités élémentaires, appariement to-source) ;
Phase 0 close (Three.js/WebGL, web mobile, statique) ; vigilance apophatique continue
validée formellement. Convention degre_vertical actée (échelle des 38 degrés ;
barzakh = 19.5, nœuds traversants/structurants = null) et appliquée dans
instrument-donnees.yaml v0.2 (validé au générateur, 0 erreur). Feuille de route 02-
et backlogs 04- mis à jour en conséquence.
```

## 5. Points sensibles

- **Le dépôt de ce lot vaut validation** par Sidy de la convention `degre_vertical`
  et de ses assignations (seul barzakh porte une valeur).
- **Deux réserves `to-source` explicites**, à ne lever qu'avec la source physique :
  l'appariement qualité ↔ angle (schéma manuscrit) et les colonnes des degrés
  21-23 / 25-27 (Gloton). Rien à inventer entre-temps.
- La proposition « filament » pour Al-Insān al-Kāmil est marquée **non validée**
  dans la v0.3 — ne pas la traiter comme actée.
- `instrument-donnees.yaml` : remplacement de fichier (v0.1 → v0.2), pas de fusion.

## 6. Liens à vérifier à l'intégration

- Les wikilinks de la v0.3 (identiques à la v0.2 + `spec-generateur-manifeste`).
- Si l'intégration du lot précédent (générateur) n'a pas encore eu lieu : intégrer
  les deux lots dans l'ordre (générateur d'abord, puis celui-ci — le yaml v0.2
  écrase le v0.1).
