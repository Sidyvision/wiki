# MASTER UPDATE — Lot « Protocole du Don, Équipe d'agents, Économie » (2026-07-05)

> ⚠️ **Lot volumineux touchant `doctrinal/`, `label/` et `meta/`.** Destiné à être
> intégré par Claude Code (moteur Qwen3.6-27B-FP8). **NE PAS employer la consigne large
> « intègre `_inbox/` ».** L'expérience Ornith/Qwen a montré qu'un lot doctrinal +
> multi-circuits doit être traité **fiche par fiche, dans l'ordre ci-dessous**, chaque
> écriture relue avant validation (jamais d'auto-accept), et clôturé par la
> vérification mécanique habituelle. Ce fichier est la feuille de route d'intégration ;
> il ne se range pas lui-même (le supprimer de `_inbox/` en fin de course).

---

## 0. Rappels de supervision (valables pour tout le lot)

- **Une fiche à la fois.** Lire la fiche source + sa consigne ici, écrire la cible,
  relire, valider, passer à la suivante.
- **Jamais d'auto-accept.** Chaque `Write`/`Update` relu avant exécution.
- **`annales.md` est append-only** : insérer une entrée, ne jamais réécrire le fichier.
- **Étanchéité** : ce lot crée des liens `label/ → doctrinal/` à **sens unique** et une
  fiche `meta/`. Vérifier qu'aucun lien inverse n'est introduit.
- **Clôturer** par la vérification mécanique (script `compare` ou équivalent), jamais
  par l'auto-rapport du modèle.

---

## 1. Ordre d'intégration séquencé

> Les fiches marquées **[À RÉDIGER PAR FABLE 5]** ne sont pas encore écrites : ce lot
> contient leur **spécification** (voir `PLAN-REDACTION-fable5.md`). Si elles sont
> présentes dans `_inbox/` au moment de l'intégration, les traiter ; sinon, sauter et
> intégrer ce qui est présent, dans l'ordre.

### Séquence A — Doctrinal d'abord (le plus sensible)

1. **`discernement/2026-07-05_correspondances-fonctions-initiatiques-entreprise.md`**
   → `doctrinal/discernement/` **[À RÉDIGER PAR FABLE 5]**
   - Bloc 🔍 Discernement complet (Statut *en cours*, Hypothèse initiale datée,
     Généalogie des idées, Examen formel, Conclusion, Lectures suggérées).
   - **Verdict laissé à Sidy** (Cmd 12) — l'IA ne tranche pas.
   - Vérifier existence des cibles `cross_links` (`hadarat-khams`, `ilm-al-nujum`,
     `manazil-al-qamar`) AVANT écriture.
   - Mettre à jour `doctrinal/index.md` §VII (Discernements) + une ligne
     `doctrinal/annales.md`.

### Séquence B — Ossature label déjà existante : mises à jour

2. **`label/index.md`** — `Update` ciblé : ajouter les nouvelles fiches (§ III-IX) et
   compléter le backlog §X (voir liste en §3 ci-dessous). Ne pas réécrire la fiche.

3. **`label/annales.md`** — `Update` append-only : une entrée
   `## [2026-07-05] grand-lot | Protocole du don, équipe 12 agents, économie, fanzine, merchandising`

### Séquence C — Distribution (le protocole du don)

4. `label/distribution/doctrine-du-don.md` **[À RÉDIGER]** — principe unifié.
   Lien suggéré (pointillé + 🔍) vers la fiche discernement de la Séquence A.
5. `label/distribution/strategie-vinyle-300-depositaires.md` **[À RÉDIGER]**
6. `label/distribution/protocole-cercles-token.md` **[À RÉDIGER]** — `statut: idee`.
7. `label/distribution/merchandising.md` **[À RÉDIGER]**

### Séquence D — Direction artistique (amorçages conceptuels)

8. `label/direction-artistique/amorcage/imaginaire-nen-ruche-echecs.md` **[À RÉDIGER]**
   — `en-gestation` ; lien sens unique possible vers `doctrinal/` (suggéré).
9. `label/direction-artistique/amorcage/generation-non-cumulative.md` **[À RÉDIGER]**

### Séquence E — Production & communication

10. `label/production/modele-economique.md` **[À RÉDIGER]** — don ↔ rentabilité.
11. `label/marketing-communication/fanzine.md` **[À RÉDIGER]** — nom : *Dans l'Absolu*.
12. `label/production/equipe-agents-hermes.md` — **fiche fournie, rédigée** (voir ce lot).

### Séquence F — Meta (system prompts des agents)

13. `meta/projet-unifie/hermes-prompts/` — **12 fichiers** `.md` **[À RÉDIGER]**
    (un par agent). Rangés en `meta/`, jamais dans `label/`. Ne contiennent aucun
    secret ; en anglais (voir spec).

---

## 2. Rappel — la fiche `meta/note-identite-publique-contexte.md`

Si non encore intégrée (lot précédent), elle reste en `meta/`. Aucune reformulation de
son contenu dans les fiches de ce lot. Les agents (Séquence F) n'ont pas accès au
contexte personnel : leurs prompts ne citent jamais le motif de la discrétion, seulement
les règles de design publiques.

---

## 3. Ajouts au backlog `label/index.md` §X

- Nom du label · alias public · titre album 01 (décisions de nommage groupées) —
  **le fanzine, lui, est nommé : *Dans l'Absolu***.
- Correspondances doctrinales 5↔5 / 12↔duodénaire : **statut suggéré**, verdict en
  attente (fiche discernement Séquence A).
- Installation Hermes (Phase 1) en attente (contrainte budgétaire) — les 12 prompts
  sont prêts à coller le moment venu.
- SDRM même pour tirage gratuit (300 vinyles) : vérifier avant pressage.
- Liste cible des dépositaires à compléter (Jazzy Sport, Beams Records amorcés).

---

## 4. Contrôles VIGILANCE de fin de lot

1. Tous les frontmatters au Sceau (label / doctrinal / meta selon le circuit).
2. Liens `label/ → doctrinal/` tous à sens unique et marqués suggérés là où non validés.
3. Aucun lien `doctrinal/ → label/`, aucun `label/ → meta/`.
4. Cibles `cross_links` de la fiche discernement vérifiées existantes.
5. `_inbox/` vidé, y compris ce MASTER UPDATE et le PLAN, en fin d'intégration.
